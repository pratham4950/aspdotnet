﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Test<int> obj = new Test<int>();
            Console.Write(obj.GetData(3, 7));

            //Test<int> obj = new Test<int>();
            //List<int> objs = new List<int>();
            //objs.Add(1);
            //objs.Add(2);
            //objs.Add(2);
            //Console.WriteLine(obj.GetList(objs));
            
            //Test<string> obj1 = new Test<string>();
            //List<string> objs1 = new List<string>();
            //objs1.Add("A");
            //objs1.Add("b");
            //objs1.Add("c");
            //Console.WriteLine(obj1.GetList(objs1));

            Console.ReadKey();
        }
    }


    public class Test<T>
    {
        //T vari;

        public T GetData(T a, T b)
        {
            dynamic val1 = a;
            dynamic val2 = b;
            return val1 + val2;
        }

        //public T GetList(List<T> a)
        //{
        //    dynamic v1;
        //    T v2=default(T);
        //    foreach (var x in a)
        //    {
        //        v1 = x;
        //        v2 += v1;
        //    }
        //    return v2;
        //}

    }

}
