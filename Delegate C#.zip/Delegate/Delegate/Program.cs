﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee() { id = 101, Name = "Pinank", Salary = 5000, Experience = 5 });
            emplist.Add(new Employee() { id = 102, Name = "Rahul", Salary = 4000, Experience = 4 });
            emplist.Add(new Employee() { id = 103, Name = "Swapnil", Salary = 3000, Experience = 3 });

            IsPromotable isPromotable = new IsPromotable(Promote);

            Employee.PromoteEmployee(emplist, isPromotable);
        }

        public static bool Promote(Employee emp)
        {
            if(emp.Experience >= 5)
            {
                return true;
            }
            else 
            {
                return false;
            }
        }

    }
}

delegate bool IsPromotable (Employee emp);

class Employee
{
    public int id { get; set; }
    public string Name { get; set; }
    public int Salary { get; set; }
    public int Experience { get; set; }

    public static void PromoteEmployee(List<Employee> employeelist, IsPromotable IsEligibleToPromote)
    {
        foreach (Employee employee in employeelist)
        {
            if(IsEligibleToPromote(employee))
            {
                Console.WriteLine(employee.Name + ": Promoted");
                Console.ReadKey();
            }
        }
    }

}
