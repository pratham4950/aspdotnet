﻿using Newtonsoft.Json;
using SerializeJSon;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Serialization;


namespace ConsumeWCF
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string WebServiceURL = string.Empty;
        public string AuthKey = "YmlzY29vdDpiaXNjb290NDU0NQ==";

        protected void Page_Load(object sender, EventArgs e)
        {
            WebServiceURL = ConfigurationManager.AppSettings["WebServiceURL"];

            if (!IsPostBack)
            {
                GetAllData();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string _Url = WebServiceURL + "GetEmpData";
            string URL = _Url + "?Id=" + TextBox1.Text+"&FirstNm=" + TextBox2.Text;
            string data = new WebClient().DownloadString(URL);
            var myNewBook = JsonConvert.DeserializeObject<List<Contact>>(data);
            GridView1.DataSource = myNewBook;
            GridView1.DataBind();
        }

        private void GetAllData()
        {
            string data = new WebClient().DownloadString( WebServiceURL + "GetAll_Data");
            var myNewBook = JsonConvert.DeserializeObject<List<Contact>>(data);
            GridView1.DataSource = myNewBook;
            GridView1.DataBind();
        }

        public string CheckAute()
        {
            WebRequest request = (HttpWebRequest)WebRequest.Create(WebServiceURL);
            request.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(AuthKey)));
            return null;
        }

        public static T DeserializeXMLFileToObject<T>(string XmlFilename)
        {
            T returnObject = default(T);
            if (string.IsNullOrEmpty(XmlFilename)) return default(T);

            try
            {
                StreamReader xmlStream = new StreamReader(XmlFilename);
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                returnObject = (T)serializer.Deserialize(xmlStream);
            }
            catch (Exception ex)
            {
                //ExceptionLogger.WriteExceptionToConsole(ex, DateTime.Now);
            }
            return returnObject;
        }
        
        protected void Button2_Click(object sender, EventArgs e)
        {
            var Urls = "http://localhost:58467/Service2.svc/Get_Data";
            StreamReader xmlStream = new StreamReader(Urls);
            //XmlSerializer objxml = new XmlSerializer(Urls);

            //Contact p = (Contact)serializer.Deserialize(Urls);

            //var MyObj = DeserializeXMLFileToObject<List<Contact>>(Urls);
            //GridView1.DataSource = MyObj;
            //GridView1.DataBind();
        }

    }
}