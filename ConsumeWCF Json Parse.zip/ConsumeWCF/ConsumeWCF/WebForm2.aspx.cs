﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ConsumeWCF
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        string WebServiceURL = "https://jsonplaceholder.typicode.com/";
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        
        protected void Button1_Click1(object sender, EventArgs e)
        {
            string _Url = WebServiceURL + "posts";
            string data = new WebClient().DownloadString(_Url);
            var myNewBook = JsonConvert.DeserializeObject<List<Users>>(data);
            GridView1.DataSource = myNewBook;
            GridView1.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Users objus = new Users();
            string _Url = WebServiceURL + "posts/" + TextBox1.Text;
            string data = new WebClient().DownloadString(_Url);
            Dictionary<string, string> values = JsonConvert.DeserializeObject<Dictionary<string, string>>(data);
            GridView1.DataSource = values;
            GridView1.DataBind();

        }

    }
}