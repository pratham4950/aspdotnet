﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SerializeJSon
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here

        [OperationContract]
        [WebInvoke(Method = "GET",
                  ResponseFormat = WebMessageFormat.Json,
                  UriTemplate = "/GetAll_Data", BodyStyle = WebMessageBodyStyle.Bare)]
        List<Contact> GetAll_Data();


        [OperationContract]
        [WebInvoke(Method = "GET",
                  ResponseFormat = WebMessageFormat.Json,
                  UriTemplate = "/GetEmpData?Id={Id}&FirstNm={FirstNm}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<Contact> GetEmpData(int Id, string FirstNm);

        
        [OperationContract]
        [WebInvoke(Method = "GET",
                  ResponseFormat = WebMessageFormat.Json,
                  UriTemplate = "/GetEmplyeeDetails?Id={Id}", BodyStyle = WebMessageBodyStyle.Bare)]
        Contact GetEmplyeeDetails(int Id);


        [OperationContract]
        [WebInvoke(Method = "GET",
                  ResponseFormat = WebMessageFormat.Json,
                  UriTemplate = "/CheckAuthentication", BodyStyle = WebMessageBodyStyle.Bare)]
        string CheckAuthentication();


    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }

    //[DataContract]
    //public class Employee
    //{

    //    string firstname = string.Empty;
    //    string lastname = string.Empty;
    //    int birthyear = 0;

    //    [DataMember]
    //    public string FirstName
    //    {
    //        get { return firstname; }
    //        set { firstname = value; }
    //    }

    //    [DataMember]
    //    public string LastName
    //    {
    //        get { return lastname; }
    //        set { lastname = value; }
    //    }

    //    [DataMember]
    //    public int BirthYear
    //    {
    //        get { return birthyear; }
    //        set { birthyear = value; }
    //    }

    //}


    
    public class Contact
    {
        
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Company { get; set; }

        public string Title { get; set; }

        public int status { get; set; }

        [DataMember(Name = "Message", Order = 23)]
        public string Message { get; set; }

    }

}
