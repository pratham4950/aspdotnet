﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Web;


namespace SerializeJSon
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service2" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service2.svc or Service2.svc.cs at the Solution Explorer and start debugging.
    public class Service2 : IService2
    {
        private string strConnection = ConfigurationManager.ConnectionStrings["conn"].ToString();

        public void DoWork()
        {
        }

        public List<Contact> Get_Data()
        {
            List<Contact> objemp = new List<Contact>();
            //objemp.Add(new Employee { BirthYear = 1990, FirstName = "test1", LastName = "city1" });
            //objemp.Add(new Employee { BirthYear = 1992, FirstName = "test2", LastName = "city2" });
            using (SqlConnection con = new SqlConnection(strConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from contacts", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dtresult1 = new DataTable();
                da.Fill(dtresult1);

                if (dtresult1.Rows.Count > 0)
                {
                    for (int i = 0; i < dtresult1.Rows.Count; i++)
                    {
                        Contact userInfo = new Contact();
                        userInfo.Id = Convert.ToInt16(dtresult1.Rows[i]["Id"]);
                        userInfo.FirstName = dtresult1.Rows[i]["FirstName"].ToString();
                        userInfo.LastName = dtresult1.Rows[i]["LastName"].ToString();
                        userInfo.Email = dtresult1.Rows[i]["Email"].ToString();
                        userInfo.Company = dtresult1.Rows[i]["Company"].ToString();
                        userInfo.Title = dtresult1.Rows[i]["Title"].ToString();
                        objemp.Add(userInfo);
                    }
                }
                con.Close();
            }
            return objemp;
        }


    }
}
