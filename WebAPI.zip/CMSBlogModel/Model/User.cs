﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMSBlogModel
{
    [MetadataType(typeof(Userdata))]
    public partial class User
    {
       
    }
    
    public class Userdata
    {
        [Required]
        public string username { get; set; }

        [Required]
        public string password { get; set; }

    }

}
