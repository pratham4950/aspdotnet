﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPICMS.Repository
{
    public interface IRegistration
    {
        IEnumerable<User> GetUsers();
        bool ValidateUser(User users);

        User GetUsersID(int id);

        bool InserUser(User users);

        bool UpdateUser(User users, int id);

    }
}
