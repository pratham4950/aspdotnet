﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPICMS.Repository
{
   public interface IUserRole : IDisposable
    {
        IEnumerable<Role> GetRoles();

        Role GetRoleByID(int roleId);
        void InsertRole(Role role);
        void DeleteRole(int roleID);
        void UpdateRole(Role role, int Id);
        void Save();

    }
}
