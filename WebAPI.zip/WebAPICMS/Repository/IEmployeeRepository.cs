﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPICMS.Repository
{
    public interface IEmployeeRepository : IDisposable
    {
        IEnumerable<Employee> GetEmployees();
        Employee GetEmpByID(int empId);
        void InsertEmployee(Employee emp);
        void DeleteEmployee(int empID);
        void UpdateEmployee(Employee emp, int Id);
        void Save();

    }
}
