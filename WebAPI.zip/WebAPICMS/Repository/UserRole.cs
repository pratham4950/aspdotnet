﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using CMSBlogModel;

namespace WebAPICMS.Repository
{
    public class UserRole : IUserRole
    {
        private BloggingEntities _context;

        public UserRole(BloggingEntities context)
        {
            _context = context;
        }

        public IEnumerable<Role> GetRoles()
        {
            return _context.Roles.ToList();
        }
        public Role GetRoleByID(int roleId)
        {
            return _context.Roles.Find(roleId);
        }
        
        public void InsertRole(Role role)
        {
            _context.Roles.Add(role);
            Save();
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public void UpdateRole(Role role, int Id)
        {
            Role objrole = _context.Roles.Where(s => s.id == Id).FirstOrDefault();
            if (objrole != null)
            {
                objrole.role1 = role.role1;
                _context.Entry(objrole).State = EntityState.Modified;
                _context.SaveChangesAsync();
            }
        }

        public void DeleteRole(int roleID)
        {
            Role role = _context.Roles.Find(roleID);
            _context.Roles.Remove(role);
            Save();
        }


        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}