﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebAPICMS.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private BloggingEntities _context;

        public EmployeeRepository(BloggingEntities context)
        {
            this._context = context;
        }

        public IEnumerable<Employee> GetEmployees()
        {
            return _context.Employees.ToList();
        }

        public Employee GetEmpByID(int empId)
        {
            return _context.Employees.Find(empId);
        }

        public void InsertEmployee(Employee emp)
        {
            //_context.Employees.Add(emp);
            //Save();

            if (emp.EmployeeID > 0)
            {
                //Edit 
                var v = _context.Employees.Where(s => s.EmployeeID == emp.EmployeeID).FirstOrDefault();
                if (v != null)
                {
                    v.FirstName = emp.FirstName;
                    v.LastName = emp.LastName;
                    v.EmailID = emp.EmailID;
                    v.City = emp.City;
                    v.Country = emp.Country;
                    //_context.Entry(objrole).State = EntityState.Modified;
                    //_context.SaveChangesAsync();
                }
            }
            else
            {
                //Save
                _context.Employees.Add(emp);
            }
            Save();
        }
        public void UpdateEmployee(Employee emp, int Id)
        {
            if (emp.EmployeeID > 0)
            {
                //Edit 
                var v = _context.Employees.Where(s => s.EmployeeID == Id).FirstOrDefault();
                if (v != null)
                {
                    v.FirstName = emp.FirstName;
                    v.LastName = emp.LastName;
                    v.EmailID = emp.EmailID;
                    v.City = emp.City;
                    v.Country = emp.Country;
                    //_context.Entry(objrole).State = EntityState.Modified;
                    //_context.SaveChangesAsync();
                }
                else
                {
                    //Save
                    _context.Employees.Add(emp);
                }
                Save();
            }            
        }

        public void DeleteEmployee(int empID)
        {
            var v = _context.Employees.Where(a => a.EmployeeID == empID).FirstOrDefault();
            if (v != null)
            {
                _context.Employees.Remove(v);
                Save();
            }
        }
        
        public void Save()
        {
            _context.SaveChanges();
        }


        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


    }
}