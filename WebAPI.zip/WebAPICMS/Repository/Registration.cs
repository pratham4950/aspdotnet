﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace WebAPICMS.Repository
{
    public class Registration : IRegistration
    {
        private readonly BloggingEntities _context;

        public Registration(BloggingEntities context)
        {
            this._context = context;
        }
        public IEnumerable<User> GetUsers()
        {
            return _context.Users.ToList();
        }

        public User GetUsersID(int id)
        {
            return _context.Users.Where(m => m.Id == id).SingleOrDefault();
        }


        public bool ValidateUser(User users)
        {
            bool isvalid = false;
            try
            {
                User objUser = new User();
                objUser = _context.Users.FirstOrDefault(qr => qr.username == users.username && qr.password == users.password);
                if (objUser != null)
                {
                    isvalid = true;
                }
                else
                {
                    isvalid = false;
                }
            }
            catch (Exception)
            {

            }
            return isvalid;
        }
        
        public bool InserUser([FromBody]User users)
        {
            bool isadded = false;
            try
            {
                _context.Users.Add(users);
                _context.SaveChanges();
                isadded = true;
            }
            catch (Exception)
            {
            }
            return isadded;
        }

        public bool UpdateUser(User users, int id)
        {
            bool isadded = false;
            try
            {
                User objCmsSite = _context.Users.Where(s => s.Id == id).FirstOrDefault();
                if (objCmsSite != null)
                {
                    objCmsSite.username = users.username;
                    objCmsSite.password = users.password;
                    _context.Entry(objCmsSite).State = EntityState.Modified;
                    _context.SaveChangesAsync();
                    isadded = true;
                }                
            }
            catch (Exception ex)
            {
            }
            return isadded;
        }

    }
}