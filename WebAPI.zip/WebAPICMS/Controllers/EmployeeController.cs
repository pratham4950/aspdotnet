﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPICMS.Repository;

namespace WebAPICMS.Controllers
{
    public class EmployeeController : ApiController
    {
       private IEmployeeRepository _repository;

        public EmployeeController(IEmployeeRepository repository)
        {
            _repository = repository;
        }

        [Route("api/employee/getdetails")]
        public IEnumerable<Employee> Get()
        {
            return _repository.GetEmployees();
        }

        [Route("api/employee/getdetails/{id}")]
        public Employee Get(int id)
        {
            return _repository.GetEmpByID(id);
        }

        [HttpPost]
        [Route("api/employee/save")]
        public void EmployeeSave(Employee emp)
        {
            _repository.InsertEmployee(emp);
        }

        [HttpPost]
        [Route("api/employee/update/{id}")]
        public void EmployeeUpdate(Employee emp, int id)
        {
            _repository.UpdateEmployee(emp, id);
        }


    }
}
