﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPICMS.Repository;

namespace WebAPICMS.Controllers
{
    public class RoleManagmentController : ApiController
    {
        private IUserRole _reposotory;

        public RoleManagmentController(IUserRole reposotory)
        {
            _reposotory = reposotory;
        }

        [HttpGet]
        [Route("api/Role/GetRoles")]
        public IEnumerable<Role> GetRoles()
        {
            return _reposotory.GetRoles();
        }

        [HttpGet]
        [Route("api/Role/GetRoleByID/{id}")]
        public Role GetRoleByID(int id)
        {
            return _reposotory.GetRoleByID(id);
        }

        [HttpPost]
        [Route("api/Role/InserRole")]
        public void InserRole(Role role)
        {
            _reposotory.InsertRole(role);
        }

        [HttpPost]
        [Route("api/Role/UpdateRole/{Id}")]
        public void UpdateRole(Role role,int Id)
        {
            _reposotory.UpdateRole(role,Id);
        }



        



    }
}
