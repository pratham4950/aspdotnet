﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebAPICMS.Repository;

namespace WebAPICMS.Controllers
{
    public class LoginController : ApiController
    {
        private IRegistration _registration;
        public LoginController(IRegistration registration)
        {
            this._registration = registration;
        }

        #region
        //public HttpResponseMessage Get()
        //{
        //    try
        //    {
        //        return Request.CreateResponse(HttpStatusCode.Found, _registration.GetUsers());
        //    }
        //    catch (Exception)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No Data found");
        //    }
        //}

        //public HttpResponseMessage Get(int id)
        //{
        //    try
        //    {
        //        return Request.CreateResponse(HttpStatusCode.Found, _registration.GetUsersID(id));
        //    }
        //    catch (Exception)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No Data found");
        //    }
        //}

        //public HttpResponseMessage Post([FromBody] User product)
        //{
        //    try
        //    {
        //        _registration.InserUser(product);
        //        var response = Request.CreateResponse(HttpStatusCode.Created, product);
        //        response.Headers.Location = Request.RequestUri;

        //        return response;
        //    }
        //    catch (Exception)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Data not inserted");
        //    }
        //}

        //public HttpResponseMessage Put([FromBody] User product, int id)
        //{
        //    try
        //    {
        //        var entity = _registration.UpdateUser(product, id);               
        //        return Request.CreateResponse(HttpStatusCode.OK, "Product Updated Successfully");
        //    }
        //    catch (Exception ex)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
        //    }
        //}
        #endregion

        //http://localhost:52295/api/Login/details
        [HttpGet]
        [Route("api/Login/details")]
        public IEnumerable<User> Getdetails()
        {
            return _registration.GetUsers().ToList();
        }

        ////http://localhost:52295/api/Login/details/1
        [HttpGet]
        [Route("api/Login/details/{id}")]
        public List<User> Getdetails(int id)
        {

            List<User> listcmsuser = new List<User>();
            var result = _registration.GetUsers();

            result = result.Where(a => a.Id == id).ToList();

            if (result != null)
            {
                foreach (var obj in result)
                {
                    User objCmsUserDetails = new User();
                    objCmsUserDetails.Id = obj.Id;
                    objCmsUserDetails.username = obj.username;
                    objCmsUserDetails.password = obj.password;

                    listcmsuser.Add(objCmsUserDetails);
                }
            }
            return listcmsuser;
        }

        ////http://localhost:52295/api/Login/details/1/pinank
        [HttpGet]
        [Route("api/Login/details/{id}/{username}")]
        public List<User> Getdetails(int id, string username)
        {

            List<User> listcmsuser = new List<User>();
            var result = _registration.GetUsers();

            result = result.Where(a => a.Id == id && a.username == username).ToList();

            if (result != null)
            {
                foreach (var obj in result)
                {
                    User objCmsUserDetails = new User();
                    objCmsUserDetails.Id = obj.Id;
                    objCmsUserDetails.username = obj.username;
                    objCmsUserDetails.password = obj.password;

                    listcmsuser.Add(objCmsUserDetails);
                }
            }
            return listcmsuser;
        }

        //http://localhost:52295/api/login/login
        [HttpPost]
        [Route("api/Login/Login")]
        public bool Login(User user)
        {
            var result = _registration.ValidateUser(user);
            return result;
        }
        
        //http://localhost:52295/api/Login/CreateUser
        [HttpPost]
        [Route("api/Login/CreateUser")]
        public bool InserUser(User user)
        {
            var result = _registration.InserUser(user);
            return result;
        }

        [Route("api/Login/UpdateUsers/{id}")]
        public bool UpdateUsers(int id, [FromBody]User user)
        {
           var result = _registration.UpdateUser(user, id);
            return result;
        }

    }
}
