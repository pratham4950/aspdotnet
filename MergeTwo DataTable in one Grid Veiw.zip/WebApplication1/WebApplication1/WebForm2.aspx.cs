﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm2 : System.Web.UI.Page
    {

        private string strConnection = ConfigurationManager.ConnectionStrings["conn"].ToString();

        List<contacts1> userdetails = new List<contacts1>();
        List<EMP1> empdetails = new List<EMP1>();
        List<string> Merge = new List<string>();

        DataTable dtresult1 = new DataTable();
        DataTable dtresult2 = new DataTable();
        DataTable meargedt = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }

        protected void btncontacts_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(strConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from contacts", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dtresult1);

                //dtresult1.Columns.Add("Password", typeof(string));

                if (dtresult1.Rows.Count > 0)
                {
                    for (int i = 0; i < dtresult1.Rows.Count; i++)
                    {
                        contacts1 userInfo = new contacts1();

                        userInfo.id = Convert.ToInt16(dtresult1.Rows[i]["Id"]);
                        userInfo.FirstName = dtresult1.Rows[i]["FirstName"].ToString();
                        userInfo.LastName = dtresult1.Rows[i]["LastName"].ToString();
                        userInfo.Email = dtresult1.Rows[i]["Email"].ToString();
                        userInfo.Company = dtresult1.Rows[i]["Company"].ToString();
                        userInfo.Title = dtresult1.Rows[i]["Title"].ToString();
                        //userInfo.Password = dtresult1.Rows[i]["Password"].ToString();
                        userdetails.Add(userInfo);

                    }
                }
                Session["Rec1"] = dtresult1;
                GridView1.DataSource = dtresult1;
                GridView1.DataBind();
                con.Close();
            }
        }

        protected void btnemp_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(strConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from emp", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dtresult2);

                //dtresult2.Columns.Add("Enrolment", typeof(string));

                if (dtresult2.Rows.Count > 0)
                {
                    for (int i = 0; i < dtresult2.Rows.Count; i++)
                    {
                        EMP1 empInfo = new EMP1();

                        empInfo.City = dtresult2.Rows[i]["city"].ToString();
                        empInfo.State = dtresult2.Rows[i]["State"].ToString();
                        //empInfo.Enrolment = dtresult2.Rows[i]["Enrolment"].ToString();
                        empInfo.cid = Convert.ToInt16(dtresult2.Rows[i]["CID"]);
                        empdetails.Add(empInfo);
                    }
                }
                Session["Rec2"] = dtresult2;
                GridView2.DataSource = dtresult2;
                GridView2.DataBind();
                con.Close();
            }
        }

        protected void btnmearge_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            DataTable dt1 = (DataTable)Session["Rec1"];
            DataTable dt2 = (DataTable)Session["Rec2"];

            dt1.PrimaryKey = new DataColumn[] { dt1.Columns["Id"] };
            dt2.PrimaryKey = new DataColumn[] { dt2.Columns["cid"] };

            ds.Tables.Add(dt1);
            ds.Tables.Add(dt2);

            DataRelation drel = new DataRelation("EquiJoin", dt2.Columns["cid"], dt1.Columns["Id"]);
            ds.Relations.Add(drel);
            DataTable jt = new DataTable("Joinedtable");

            jt.Columns.Add("id", typeof(Int32));
            jt.Columns.Add("FirstName", typeof(String));
            jt.Columns.Add("LastName", typeof(String));
            jt.Columns.Add("Email", typeof(String));
            jt.Columns.Add("Company", typeof(String));
            jt.Columns.Add("Title", typeof(String));
            jt.Columns.Add("City", typeof(String));
            jt.Columns.Add("State", typeof(String));

            ds.Tables.Add(jt);

            foreach (DataRow dr in ds.Tables["Table1"].Rows)
            {
                DataRow parent = dr.GetParentRow("EquiJoin");
                DataRow current = jt.NewRow();
                // Just add all the columns' data in "dr" to the New table.
                for (int i = 0; i < ds.Tables["Table1"].Columns.Count; i++)
                {
                    current[i] = dr[i];
                }
                // Add the column that is not present in the child, which is present in the parent.
                current["City"] = parent["City"];
                current["State"] = parent["State"];
                jt.Rows.Add(current);
            }

            GridView3.DataSource = ds.Tables["Joinedtable"];
            GridView3.DataBind();

        }



    }
}