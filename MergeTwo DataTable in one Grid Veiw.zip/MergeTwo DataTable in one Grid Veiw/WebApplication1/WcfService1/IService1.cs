﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here

        [OperationContract]
        List<contacts> GetUserDetails();

        [OperationContract]
        List<EMP> GetEMPDetails();


        [OperationContract]
        DataTable GetMerge();

        [OperationContract]
        string ReturnValues();

        [OperationContract]
        string InsertUserDetails(contacts userInfo);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}

public class contacts
{
    string firstname = string.Empty;
    string lastname = string.Empty;
    string email = string.Empty;
    string company = string.Empty;
    string title = string.Empty;
    string password = string.Empty;

    [DataMember]
    public string Email
    {
        get { return email; }
        set { email = value; }
    }
    [DataMember]
    public string FirstName
    {
        get { return firstname; }
        set { firstname = value; }
    }
    [DataMember]
    public string LastName
    {
        get { return lastname; }
        set { lastname = value; }
    }
    [DataMember]
    public string Company
    {
        get { return company; }
        set { company = value; }
    }
    [DataMember]
    public string Title
    {
        get { return title; }
        set { title = value; }
    }

    [DataMember]
    public string Password
    {
        get { return password; }
        set { password = value; }
    }

}


public class EMP
{
    string city = string.Empty;
    string state = string.Empty;
    string enrolment = string.Empty;

    
    [DataMember]
    public string City
    {
        get { return city; }
        set { city = value; }
    }
    [DataMember]
    public string State
    {
        get { return state; }
        set { state = value; }
    }
    [DataMember]
    public string Enrolment
    {
        get { return enrolment; }
        set { enrolment = value; }
    }

}
