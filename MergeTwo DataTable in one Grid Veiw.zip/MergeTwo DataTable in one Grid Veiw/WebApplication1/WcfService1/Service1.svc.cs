﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        private string strConnection = ConfigurationManager.ConnectionStrings["conn"].ToString();

        List<contacts> userdetails = new List<contacts>();
        List<EMP> empdetails = new List<EMP>();
        List<string> Merge = new List<string>();

        DataTable dtresult1 = new DataTable();
        DataTable dtresult2 = new DataTable();
        DataTable meargedt = new DataTable();



        public List<contacts> GetUserDetails()
        {
            using (SqlConnection con = new SqlConnection(strConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from contacts", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(dtresult1);

                dtresult1.Columns.Add("Password", typeof(string));

                if (dtresult1.Rows.Count > 0)
                {
                    for (int i = 0; i < dtresult1.Rows.Count; i++)
                    {
                        contacts userInfo = new contacts();
                        
                        userInfo.FirstName = dtresult1.Rows[i]["FirstName"].ToString();
                        userInfo.LastName = dtresult1.Rows[i]["LastName"].ToString();
                        userInfo.Email = dtresult1.Rows[i]["Email"].ToString();
                        userInfo.Company = dtresult1.Rows[i]["Company"].ToString();
                        userInfo.Title = dtresult1.Rows[i]["Title"].ToString();
                        userInfo.Password = dtresult1.Rows[i]["Password"].ToString();
                        userdetails.Add(userInfo);

                    }
                }
                con.Close();
            }
            return userdetails;

        }

        public List<EMP> GetEMPDetails()
        {   
            using (SqlConnection con = new SqlConnection(strConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from emp", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                
                da.Fill(dtresult2);

                dtresult2.Columns.Add("Enrolment", typeof(string));

                if (dtresult2.Rows.Count > 0)
                {
                    for (int i = 0; i < dtresult2.Rows.Count; i++)
                    {
                        EMP empInfo = new EMP();

                        empInfo.City = dtresult2.Rows[i]["city"].ToString();
                        empInfo.State = dtresult2.Rows[i]["State"].ToString();
                        empInfo.Enrolment = dtresult2.Rows[i]["Enrolment"].ToString();
                        empdetails.Add(empInfo);
                    }
                }
                con.Close();
            }
            return empdetails;
        }

        public string InsertUserDetails(contacts userInfo)
        {
            string strMessage = string.Empty;
            using (SqlConnection con = new SqlConnection(strConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into contacts(FirstName,LastName,Email,Company,Title) values(@FName,@LName,@Email,@Company,@Title)", con);
                cmd.Parameters.AddWithValue("@Email", userInfo.Email);
                cmd.Parameters.AddWithValue("@FName", userInfo.FirstName);
                cmd.Parameters.AddWithValue("@LName", userInfo.LastName);
                cmd.Parameters.AddWithValue("@Company", userInfo.Company);
                cmd.Parameters.AddWithValue("@Title", userInfo.Title);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    strMessage = userInfo.FirstName + " Details inserted successfully";
                }
                else
                {
                    strMessage = userInfo.FirstName + " Details not inserted successfully";
                }
                con.Close();
            }
            return strMessage;
        }


        public DataTable GetMerge()
        {
            string returnvalue = string.Empty;

            DataTable dt3 = dtresult1.Copy();
            dt3.Merge(dtresult2);

            return dt3;
        }


        public string ReturnValues()
        {
            string returnvalue = string.Empty;
            returnvalue = "Hi, There!";
            return returnvalue;
        }

    }
}
