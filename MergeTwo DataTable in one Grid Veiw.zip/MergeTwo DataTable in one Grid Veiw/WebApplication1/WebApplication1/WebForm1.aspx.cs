﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.ServiceReference1;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        ServiceReference1.Service1Client objService = new ServiceReference1.Service1Client();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindUserDetails();
            }
        }
        protected void BindUserDetails()
        {
            IList<contacts> objUserDetails = new List<contacts>();
            objUserDetails = objService.GetUserDetails();
            GridView1.DataSource = objUserDetails;
            GridView1.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            contacts userInfo = new contacts();
            userInfo.Email = txtemail.Text;
            userInfo.FirstName = txtfname.Text;
            userInfo.LastName = txtlname.Text;
            userInfo.Company = txtcompany.Text;
            userInfo.Title = txttitle.Text;

            string result = objService.InsertUserDetails(userInfo);
            lblResult.Text = result;
            BindUserDetails();
            txtemail.Text = string.Empty;
            txtfname.Text = string.Empty;
            txtlname.Text = string.Empty;
            txtcompany.Text = string.Empty;
            txttitle.Text = string.Empty;
        }
    }
}