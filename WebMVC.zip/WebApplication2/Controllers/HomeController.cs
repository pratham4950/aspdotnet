﻿using CMSBlogModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Helper;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        WebAPIHelper _cmsapi = new WebAPIHelper();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Authenticate()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Authenticate(User user)
        {
            //Exception ex = null;
            //throw ex;

            if (ModelState.IsValid)
            {
                User model = WebAPIHelper.CallApi<User>(HttpMethods.Post, "login", "login", user, null);
                return View(model);
            }
            return View("Authenticate");
        }
        
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                User model = WebAPIHelper.CallApi<User>(HttpMethods.Post, "CreateUser", "Login", user, null);

                return View(model);
            }
            return View("Register");
        }

        public ActionResult Update()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Update(User user, int id)
        {
            User model = WebAPIHelper.CallApi<User>(HttpMethods.Post, "UpdateUsers", "Login", user, id);
            return View(model);
        }
        
    }
}