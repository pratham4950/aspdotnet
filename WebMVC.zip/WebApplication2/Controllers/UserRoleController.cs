﻿using CMSBlogModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Helper;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class UserRoleController : Controller
    {

        // GET: UserRole

        public ActionResult Index()
        {
            var model = WebAPIHelper.CallApi<IEnumerable<Role>>(HttpMethods.Get, "GetRoles", "Role", null, null);
            return View(model);
        }
         
        public ActionResult Save()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Save(Role role)
        {
            if (ModelState.IsValid)
            {
                Role model = WebAPIHelper.CallApi<Role>(HttpMethods.Post, "InserRole", "Role", role, null);
                return View("Index");
            }
            return View("Index");
        }

        
        //GetUsers In Dropdown
        [NonAction]
        public List<SelectListItem> GetAll_UserRoles()
        {
            List<SelectListItem> listrole = new List<SelectListItem>();
            listrole.Add(new SelectListItem
            {
                Text = "select",
                Value = "0"
            });

            var model = WebAPIHelper.CallApi<IEnumerable<Role>>(HttpMethods.Get, "GetRoles", "Role", null, null);

            foreach (var item in model)
            {
                listrole.Add(new SelectListItem
                {
                    Text = item.role1,
                    Value = Convert.ToString(item.id)
                });
            }

            return listrole;
        }

        //GetRoles In Dropdown
        [NonAction]
        public List<SelectListItem> GetAll_Users()
        {
            List<SelectListItem> listuser = new List<SelectListItem>();
            listuser.Add(new SelectListItem
            {
                Text = "Select",
                Value = "0"
            });
            
            var model = WebAPIHelper.CallApi<IEnumerable<User>>(HttpMethods.Get, "details", "Login", null, null);
            foreach (var item in model)
            {
                listuser.Add(new SelectListItem
                {
                    Text = item.username,
                    Value = Convert.ToString(item.Id)
                });
            }            
            return listuser;
        }

        [HttpGet]
        public ActionResult AssignRolesToUsers()
        {
            AssignRole _addignroles = new AssignRole();
            _addignroles.UserRolesList = GetAll_UserRoles();
            _addignroles.Userlist = GetAll_Users();
            return View(_addignroles);
            
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AssignRolesToUsers(AssignRole _assignRole)
        {
            if (_assignRole.UserRoleName == "0")
            {
                ModelState.AddModelError("RoleName", " select UserRoleName");
            }
            if (_assignRole.UserID == "0")
            {
                ModelState.AddModelError("UserName", " select Username");
            }
            if (ModelState.IsValid)
            {
                if (Get_CheckUserRoles(Convert.ToInt32(_assignRole.UserID)) == true)
                {
                    ViewBag.ResultMessage = "Current user is already has the role";
                }
                else
                {
                    var UserName = GetUserName_BY_UserID(Convert.ToInt32(_assignRole.UserID));
                    var UserRoleName = GetRoleNameByRoleID(Convert.ToInt32(_assignRole.UserRoleName));
                    //Roles.AddUserToRole(UserName, UserRoleName);
                    ViewBag.ResultMessage = "Username added to role successfully !";
                }
                _assignRole.UserRolesList = GetAll_UserRoles();
                _assignRole.Userlist = GetAll_Users();
                return View(_assignRole);
            }
            else
            {
                _assignRole.UserRolesList = GetAll_UserRoles();
                _assignRole.Userlist = GetAll_Users();
            }
            return View(_assignRole);
        }

        public User GetUserName_BY_UserID(int UserId)
        {

            //var UserName = (from UP in context.UserProfile where UP.UserId == UserId select UP.UserName).SingleOrDefault();
            var UserName = WebAPIHelper.CallApi<IEnumerable<User>>(HttpMethods.Get, "details", "Login", null, UserId).SingleOrDefault();
            return UserName;

        }

        public Role GetRoleNameByRoleID(int RoleId)
        {
            //var roleName = (from UP in context.UserRoles where UP.RoleId == RoleId select UP.RoleName).SingleOrDefault();
            var roleName = WebAPIHelper.CallApi<Role>(HttpMethods.Get, "GetRoleByID", "Role", null, RoleId);
            return roleName;
        }

        public bool Get_CheckUserRoles(int UserId)
        {
            //var data = (from WR in context.webpages_UsersInRole
            //            join R in context.UserRoles on WR.RoleId equals R.RoleId
            //            where WR.UserId == UserId
            //            orderby R.RoleId
            //            select new
            //            {
            //                WR.UserId
            //            }).Count();
            //if (data > 0)
            //{
            //    return true;
            //}
            //else
            //{
            //    return false;
            //}
            return false;
        }

    }
}