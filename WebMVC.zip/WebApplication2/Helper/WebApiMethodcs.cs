﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Helper
{
    public static class HttpMethods
    {
        public static string Post = "POST";

        public static string Get = "GET";
    }
}