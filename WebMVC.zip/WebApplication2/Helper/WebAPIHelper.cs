﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

namespace WebApplication2.Helper
{
    public class WebAPIHelper
    {
        public static string baseUrl = ConfigurationManager.AppSettings["ApiBaseUrl"];

        public static T CallApi<T>(string Method, string Action, string Controller, dynamic obj = null, int? Id = null) where T : class
        {
            HttpResponseMessage response = null;
            string url = string.Empty;
            if (Id != null)
                url = baseUrl + "api/" + Controller + "/" + Action + "/" + Id;
            else
                url = baseUrl + "api/" + Controller + "/" + Action;
            if (Method == "POST")
            {
                var httpClient = InitializeClient();
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = Int32.MaxValue;
                response = httpClient.PostAsync(url, new StringContent(ser.Serialize(obj), Encoding.UTF8, "application/json")).Result;
            }
            if (Method == "GET")
            {
                var httpClient = InitializeClient();
                response = httpClient.GetAsync(url).Result;
            }
            if (response.IsSuccessStatusCode)
            {
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                serializer.MaxJsonLength = Int32.MaxValue;
                T result = serializer.Deserialize<T>(response.Content.ReadAsStringAsync().Result); //Error
                return result;
            }
            else
            {
                throw new Exception("Problem while creating api request");
            }
        }
        public static HttpClient GetHttpClient()
        {
            var MyHttpClient = new HttpClient();
            dynamic _token = HttpContext.Current.Session["token"];
            if (_token == null) throw new ArgumentNullException(nameof(_token));
            MyHttpClient.DefaultRequestHeaders.Add("Authorization", String.Format("Bearer {0}", _token));
            return MyHttpClient;
        }

        public static HttpClient InitializeClient()
        {
            var client = new HttpClient();
            //client.BaseAddress = new Uri(baseUrl);
            //client.DefaultRequestHeaders.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }

    }
}