﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CMSBlogModel
{

    [MetadataType(typeof(Userdata))]
    public partial class User
    {
    }
    public class Userdata
    {
        [Required]
        public string username { get; set; }

        [Required]
        public string password { get; set; }

    }

}